package th.in.nattawut.plancrop.utility;

public class PreferencesUtility {

    public static final String LOGGED_IN_PREF = "logged_in_status";
}
