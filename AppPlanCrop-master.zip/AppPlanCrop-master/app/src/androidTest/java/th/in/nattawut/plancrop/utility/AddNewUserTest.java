package th.in.nattawut.plancrop.utility;

import static org.junit.Assert.*;

public class AddNewUserTest {

}